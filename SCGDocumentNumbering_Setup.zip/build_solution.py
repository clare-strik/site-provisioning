"""Build the SCG document numbering Dataverse solution without tenant calls."""
from __future__ import annotations
import argparse, copy, hashlib, json, subprocess, uuid
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parent
VERSION = '1.0.0.0'
NAMESPACE = uuid.UUID('c3b66364-52f6-41d8-86f6-2025898fcf4d')
FLOW_IDS = {f: str(uuid.uuid5(NAMESPACE, f)) for f in ('Project', 'Corporate')}
CONNECTION = 'scg_DocumentNumberingSharePoint'
CONFIG = {
    'projectParentContentTypeId': '', 'corporateParentContentTypeId': '',
    'fields': {
        'projectNumber': 'f6946573-142a-4daa-b6ba-0ef9ccace680',
        'discipline': 'e9cf8c3b-6467-4022-8c6e-72f641ad4d8c',
        'functionalScope': '2165330e-0389-43e5-865d-d2f6baad1e02',
        'systemScope': '98254995-3560-473a-998b-847d1527e57e',
        'documentType': '5b961f2f-33be-4636-8d23-444eaacec1d2',
        'sequence': '83cb4c69-630b-4ab4-8b1d-c6197d78bd81',
        'revision': '6ca80dc4-bcf0-4ed6-ac6c-18b895f46c6c',
        'documentNumber': '75ea69d6-f892-4f2d-a56b-b54056d43289',
        'status': '5720bd35-4483-430c-b50e-108df491792e',
        'message': '93fc0953-58aa-4afa-8227-977b9e683964',
        'trigger': '522dd51b-0ecb-4937-afdb-820fee441d4a'
    }
}

def expr(s): return '@' + s
def after(name, states=None): return {name: states or ['Succeeded']} if name else {}
def action(kind, inputs=None, prev=None, **extra):
    a = {'type': kind, 'runAfter': after(prev)}
    if inputs is not None: a['inputs'] = inputs
    a.update(extra)
    return a
def compose(value, prev=None): return action('Compose', value, prev)
def setvar(name, value, prev=None): return action('SetVariable', {'name': name, 'value': value}, prev)
def scope(actions, prev=None): return action('Scope', prev=prev, actions=actions)
def condition(test, yes, no=None, prev=None):
    return action('If', prev=prev, expression=expr(test), actions=yes, **{'else': {'actions': no or {}}})
def fail(message):
    return {'Reject_'+hashlib.sha256(message.encode()).hexdigest()[:12]: action('Compose', expr("div(1,0)"), description=message)}
def guard(test, message, prev=None):
    return condition(test, {}, fail(message), prev)

def http(uri, method='GET', body=None, prev=None, headers=None, retry=True):
    params = {'dataset': "@parameters('SCG Site URL (scg_SiteUrl)')",
              'parameters/method': method, 'parameters/uri': uri,
              'parameters/headers': {'Accept': 'application/json;odata=nometadata',
                                     'Content-Type': 'application/json;odata=nometadata', **(headers or {})}}
    if body is not None: params['parameters/body'] = body
    inputs = {'host': {'connectionName': 'shared_sharepointonline', 'operationId': 'HttpRequest',
                       'apiId': '/providers/Microsoft.PowerApps/apis/shared_sharepointonline'},
              'parameters': params, 'authentication': "@parameters('$authentication')"}
    if not retry: inputs['retryPolicy'] = {'type': 'none'}
    return action('OpenApiConnection', inputs, prev)

def flow(family, binding=None):
    config = copy.deepcopy(CONFIG)
    if binding: config.update({k: binding[k] for k in ('projectParentContentTypeId', 'corporateParentContentTypeId') if k in binding})
    params = {'$connections': {'defaultValue': {}, 'type': 'Object'},
              '$authentication': {'defaultValue': {}, 'type': 'SecureObject'}}
    envs = {'SCG Site URL (scg_SiteUrl)': (binding or {}).get('SiteUrl',''),
            'SCG Project Library (scg_ProjectLibraryId)': (binding or {}).get('LibraryId','') if family == 'Project' else '',
            'SCG Corporate Library (scg_CorporateLibraryId)': (binding or {}).get('LibraryId','') if family == 'Corporate' else '',
            'SCG Numbering Configuration (scg_NumberingConfiguration)': json.dumps(config, separators=(',',':'))}
    for name, default in envs.items():
        params[name] = {'type': 'String', 'defaultValue': default,
                        'metadata': {'schemaName': name.split('(')[1][:-1]}}
    lib_param = f'SCG {family} Library (scg_{family}LibraryId)'
    config_expr = "json(parameters('SCG Numbering Configuration (scg_NumberingConfiguration)'))"
    id_expr = "string(triggerBody()?['entity']?['ID'])"
    # A solution-aware SharePoint selected-file trigger. Its list binding is
    # supplied during import or fixed in a generated library-specific copy.
    trigger = {'type': 'Request', 'kind': 'ApiConnection',
               'splitOn': "@triggerBody()?['rows']", 'runtimeConfiguration': {'concurrency': {'runs': 1}},
               'inputs': {'host': {'connection': {'name': "@parameters('$connections')['shared_sharepointonline']['connectionId']"},
                                  'api': {'name': 'shared_sharepointonline'}},
                          'operationId': 'ForASelectedFileHybridTrigger',
                          'parameters': {'dataset': "@parameters('SCG Site URL (scg_SiteUrl)')", 'table': expr(f"parameters('{lib_param}')")},
                          'schema': {'type':'object','properties':{'rows':{'type':'array','items':{'type':'object',
                                     'properties':{'entity':{'type':'object','properties':{'ID':{'type':'integer','format':'int64'},'FileId':{'type':'string'}},'required':['ID']}},'required':['entity']}}},'required':['rows']}}}
    a = {}
    a['Initialize'] = action('InitializeVariable', {'variables': [
        {'name':'LibraryId','type':'string','value':expr(f"parameters('{lib_param}')")},
        {'name':'ItemId','type':'string','value':expr(id_expr)},
        {'name':'Names','type':'object','value':{}}, {'name':'Values','type':'object','value':{}},
        {'name':'Number','type':'string','value':''}, {'name':'FileName','type':'string','value':''},
        {'name':'DuplicateCount','type':'integer','value':0}, {'name':'LockReady','type':'boolean','value':False},
        {'name':'OwnsStatus','type':'boolean','value':False},
        {'name':'FailureMessage','type':'string','value':'The request failed. Review this flow run for connector details.'}
    ]})
    a['Configuration'] = compose(expr(config_expr), 'Initialize')
    list_uri = "_api/web/lists(guid'@{variables('LibraryId')}')"
    item_uri = list_uri + "/items(@{variables('ItemId')})"
    # Resolve custom fields by GUID, retaining each list copy's immutable name.
    p = {}
    p['Read_site'] = http('_api/web?$select=Url,ServerRelativeUrl')
    p['Read_library'] = http(list_uri+'?$select=Id,Title,BaseTemplate,RootFolder/ServerRelativeUrl&$expand=RootFolder', prev='Read_site')
    p['Require_document_library'] = guard("equals(int(body('Read_library')?['BaseTemplate']),101)", 'The selected list must be a document library.', 'Read_library')
    p['Read_fields'] = http(list_uri+'/fields?$select=Id,InternalName,TypeAsString&$top=5000', prev='Require_document_library')
    required = ['documentType','sequence','revision','documentNumber','status','message','trigger']
    required += ['projectNumber','discipline'] if family=='Project' else ['functionalScope','systemScope']
    last='Read_fields'
    for key in required:
        p['Find_'+key] = action('Query', {'from': "@body('Read_fields')?['value']",
            'where': expr(f"equals(toLower(item()?['Id']),toLower(body('Configuration')?['fields']?['{key}']))")}, last)
        p['Require_'+key] = guard(f"equals(length(body('Find_{key}')),1)", f'Required field {key} must resolve to exactly one GUID.', 'Find_'+key)
        accepted = ['TaxonomyFieldType'] if key in ['discipline','functionalScope','systemScope','documentType'] else ['Text']
        p['Type_'+key] = guard(f"contains(json('{json.dumps(accepted)}'),first(body('Find_{key}'))?['TypeAsString'])", f'Required field {key} has an incompatible type.', 'Require_'+key)
        p['Map_'+key] = compose(expr(f"setProperty(variables('Names'),'{key}',first(body('Find_{key}'))?['InternalName'])"), 'Type_'+key)
        p['Save_'+key] = setvar('Names', expr(f"outputs('Map_{key}')"), 'Map_'+key)
        last='Save_'+key
    p['Read_document'] = http(item_uri+'?$select=Id,Title,ContentTypeId,FileSystemObjectType,File/Name,File/ServerRelativeUrl,File/UniqueId&$expand=File', prev=last)
    rootkey=family.lower()+'ParentContentTypeId'
    p['Require_controlled_type'] = guard(
        f"and(not(empty(body('Configuration')?['{rootkey}'])),startsWith(toLower(body('Read_document')?['ContentTypeId']),toLower(body('Configuration')?['{rootkey}'])),equals(int(body('Read_document')?['FileSystemObjectType']),0))",
        'Select a file with a descendant of the configured controlled parent content type.', 'Read_document')
    p['Read_text_values'] = http(item_uri+'/FieldValuesAsText', prev='Require_controlled_type')
    p['Save_values'] = setvar('Values', "@body('Read_text_values')", 'Read_text_values')
    p['Status_available'] = guard("not(equals(variables('Values')?[variables('Names')?['status']],'In Progress'))", 'This document already has an in-progress numbering request. Inspect or reset a stale status before retrying.', 'Save_values')
    def feedback(status, message, number=None):
        values=[{'FieldName':"@variables('Names')?['status']",'FieldValue':status},
                {'FieldName':"@variables('Names')?['message']",'FieldValue':message}]
        if number is not None: values.insert(0,{'FieldName':"@variables('Names')?['documentNumber']",'FieldValue':number})
        return {'formValues':values,'bNewDocumentUpdate':False}
    # Use MERGE with the read ETag to acquire processing status without changing
    # another request's item. Further writes use ValidateUpdateListItem results.
    p['Mark_in_progress'] = http(item_uri, 'POST', expr("setProperty(setProperty(json('{}'),variables('Names')?['status'],'In Progress'),variables('Names')?['message'],'Checking metadata and document name.')"),
        'Status_available', {'IF-MATCH':"@coalesce(outputs('Read_document')?['headers']?['ETag'],body('Read_document')?['odata.etag'],body('Read_document')?['@odata.etag'])",'X-HTTP-Method':'MERGE'}, retry=False)
    p['Own_status'] = setvar('OwnsStatus', True, 'Mark_in_progress')
    p['Validation_message'] = setvar('FailureMessage','Complete all required numbering metadata. Use one taxonomy term per field, a sequence of four digits and a revision. The title and all number segments must be valid for a SharePoint filename.', 'Own_status')
    # Labels come from FieldValuesAsText, avoiding WssId or taxonomy GUIDs.
    # Only explicit spaced separators split abbreviation from description.
    for key in required:
        if key in ['documentNumber','status','message','trigger']: continue
        raw = f"trim(string(coalesce(variables('Values')?[variables('Names')?['{key}']],'')))"
        p['Value_'+key] = compose(expr(raw), 'Validation_message' if key==required[0] else None)
    # Chain all value composes deterministically.
    last='Validation_message'
    for key in required:
        if 'Value_'+key in p: p['Value_'+key]['runAfter']=after(last);last='Value_'+key
    terms=['documentType','discipline'] if family=='Project' else ['documentType','functionalScope','systemScope']
    for key in terms:
        p['Abbreviation_'+key] = compose(expr(f"trim(first(split(replace(replace(outputs('Value_{key}'),' – ',' - '),' — ',' - '),' - ')))"), last)
        last='Abbreviation_'+key
    p['Title'] = compose("@trim(string(coalesce(body('Read_document')?['Title'],'')))", last)
    checks=[f"not(empty(outputs('Value_{k}')))" for k in required if 'Value_'+k in p]
    checks += ["not(empty(outputs('Title')))","equals(length(outputs('Value_sequence')),4)"]
    digits="outputs('Value_sequence')"
    for digit in '0123456789': digits=f"replace({digits},'{digit}','')"
    checks += [f"equals({digits},'')"]
    checks += [f"not(contains(outputs('Value_{k}'),';'))" for k in terms]
    p['Validate_required_values'] = guard('and('+','.join(checks)+')', 'Required metadata, single taxonomy terms, sequence or title are invalid.', 'Title')
    components = ["outputs('Value_projectNumber')","outputs('Abbreviation_discipline')"] if family=='Project' else ["'SCG'","outputs('Abbreviation_functionalScope')","outputs('Abbreviation_systemScope')"]
    components += ["outputs('Abbreviation_documentType')","outputs('Value_sequence')","outputs('Value_revision')"]
    p['Build_number'] = setvar('Number', expr('concat('+",'-',".join(components)+')'), 'Validate_required_values')
    # Extension is taken from the original name; never generated from the title.
    p['Require_extension'] = guard("and(contains(body('Read_document')?['File']?['Name'],'.'),not(empty(last(split(body('Read_document')?['File']?['Name'],'.')))))",'The selected document needs a file extension.', 'Build_number')
    p['Build_filename'] = setvar('FileName', "@concat(variables('Number'),'_',outputs('Title'),'.',last(split(body('Read_document')?['File']?['Name'],'.')))", 'Require_extension')
    p['Invalid_filename_chars'] = action('Query', {'from': ['"','*',':','<','>','?','/','\\','|','\r','\n','\t'],
        'where': "@contains(variables('FileName'),item())"}, 'Build_filename')
    p['Validate_filename'] = guard("and(equals(length(body('Invalid_filename_chars')),0),lessOrEquals(length(variables('FileName')),255),not(endsWith(outputs('Title'),'.')),not(endsWith(outputs('Title'),' ')),not(startsWith(toLower(variables('FileName')),'_vti_')))", 'The proposed filename contains invalid characters or exceeds the component limit.', 'Invalid_filename_chars')
    p['Parent_path'] = compose("@substring(body('Read_document')?['File']?['ServerRelativeUrl'],0,lastIndexOf(body('Read_document')?['File']?['ServerRelativeUrl'],'/'))", 'Validate_filename')
    p['Destination_path'] = compose("@concat(outputs('Parent_path'),'/',variables('FileName'))", 'Parent_path')
    p['Path_message'] = setvar('FailureMessage','The full document path exceeds 400 characters. Reduce the document Title and try again.', 'Destination_path')
    p['Validate_path'] = guard("lessOrEquals(length(outputs('Destination_path')),400)", 'The decoded server-relative document path must be at most 400 characters.', 'Path_message')
    p['Duplicate_message'] = setvar('FailureMessage','A document with the proposed name already exists in the required scope. Choose a different sequence, revision or title.', 'Validate_path')
    # Enumerate actual list data recursively (no search-index delay) and reject
    # an incomplete corporate document library inventory.
    if family=='Project':
        p['Libraries_to_check'] = compose("@createArray(json(concat('{\"Id\":\"',variables('LibraryId'),'\"}')))", 'Duplicate_message')
    else:
        p['Read_document_libraries'] = http('_api/web/lists?$select=Id,Title,BaseTemplate&$filter=BaseTemplate eq 101&$top=5000', prev='Duplicate_message')
        p['Require_complete_inventory'] = guard("and(empty(body('Read_document_libraries')?['odata.nextLink']),empty(body('Read_document_libraries')?['@odata.nextLink']))", 'Site library inventory exceeded the page limit; do not proceed with an incomplete duplicate check.', 'Read_document_libraries')
        p['Libraries_to_check'] = compose("@body('Read_document_libraries')?['value']", 'Require_complete_inventory')
    p['CAML_name'] = compose("@replace(replace(replace(variables('FileName'),'&','&amp;'),'<','&lt;'),'>','&gt;')", 'Libraries_to_check')
    # FSObjType ensures folders do not count. Two results suffice to decide:
    # ignore this item only when checking its original library.
    viewxml="@concat('<View Scope=\"RecursiveAll\"><Query><Where><And><Eq><FieldRef Name=\"FSObjType\"/><Value Type=\"Integer\">0</Value></Eq><Eq><FieldRef Name=\"FileLeafRef\"/><Value Type=\"Text\">',outputs('CAML_name'),'</Value></Eq></And></Where></Query><ViewFields><FieldRef Name=\"ID\"/><FieldRef Name=\"FileRef\"/></ViewFields><RowLimit>2</RowLimit></View>')"
    duplicate_actions = {
        'Find_existing_names': http("_api/web/lists(guid'@{items('Check_libraries')?['Id']}')/GetItems",'POST',{'query':{'ViewXml':viewxml}}),
        'Other_documents': action('Query', {'from':"@body('Find_existing_names')?['value']",'where':"@not(and(equals(toLower(items('Check_libraries')?['Id']),toLower(variables('LibraryId'))),equals(string(coalesce(item()?['Id'],item()?['ID'])),variables('ItemId'))))"}, 'Find_existing_names'),
        'Count_duplicates': action('IncrementVariable', {'name':'DuplicateCount','value':"@length(body('Other_documents'))"}, 'Other_documents')
    }
    p['Check_libraries'] = action('Foreach',prev='CAML_name',foreach="@outputs('Libraries_to_check')",actions=duplicate_actions,
        runtimeConfiguration={'concurrency':{'repetitions':1}})
    p['No_duplicate'] = guard("equals(variables('DuplicateCount'),0)", 'The destination name already exists in the duplicate scope.', 'Check_libraries')
    p['Lock_message'] = setvar('FailureMessage','The document is checked out or locked for editing. Close the document and check it in, then retry. No checkout is discarded.', 'No_duplicate')
    file_uri="_api/web/GetFileById(guid'@{body('Read_document')?['File']?['UniqueId']}')"
    lock = {'Inspect_lock':http(file_uri+'?$select=CheckOutType,LockedByUser/Id&$expand=LockedByUser')}
    lock['Checkin_or_wait'] = condition("not(equals(int(body('Inspect_lock')?['CheckOutType']),2))",
        {'Check_in_preserving_changes':http(file_uri+"/CheckIn(comment='SCG document numbering: preserve pending changes',checkintype=1)",'POST')},
        {'Set_lock_ready':setvar('LockReady',"@empty(body('Inspect_lock')?['LockedByUser']?['Id'])")}, 'Inspect_lock')
    lock['Wait_if_locked'] = condition("not(variables('LockReady'))",{'Wait_10_seconds': action('Wait', {'interval':{'count':10,'unit':'Second'}})},prev='Checkin_or_wait')
    p['Wait_for_unlocked_file'] = action('Until',prev='Lock_message',expression="@equals(variables('LockReady'),true)",limit={'count':18,'timeout':'PT5M'},actions=lock)
    p['Require_unlocked'] = guard("equals(variables('LockReady'),true)", 'The document remains locked after retries.', 'Wait_for_unlocked_file')
    # Get a fresh read before writing; metadata must still match the validated
    # inputs. The service account uses the supplied connection reference.
    p['Recheck_metadata'] = http(item_uri+'/FieldValuesAsText',prev='Require_unlocked')
    p['Metadata_unchanged'] = guard("equals(body('Recheck_metadata'),setProperty(setProperty(variables('Values'),variables('Names')?['status'],'In Progress'),variables('Names')?['message'],'Checking metadata and document name.'))", 'Metadata changed while processing; retry using the current values.', 'Recheck_metadata')
    # Comparing the entire text object includes Modified and is too strict;
    # compare only the numbering inputs and Title below.
    compare=[f"equals(body('Recheck_metadata')?[variables('Names')?['{k}']],variables('Values')?[variables('Names')?['{k}']])" for k in required if 'Value_'+k in p]
    compare += ["equals(trim(string(body('Recheck_metadata')?['Title'])),outputs('Title'))"]
    p['Metadata_unchanged']['expression']=expr('and('+','.join(compare)+')')
    p['Reset_duplicate_count'] = setvar('DuplicateCount',0,'Metadata_unchanged')
    final_dupes=copy.deepcopy(duplicate_actions)
    final_dupes={name+'_final':v for name,v in final_dupes.items()}
    for name,v in final_dupes.items():
        serialized=json.dumps(v).replace("items('Check_libraries')","items('Check_libraries_final')").replace("body('Find_existing_names')","body('Find_existing_names_final')").replace("body('Other_documents')","body('Other_documents_final')")
        final_dupes[name]=json.loads(serialized)
        final_dupes[name]['runAfter']={key+'_final':value for key,value in v['runAfter'].items()}
    p['Check_libraries_final']=action('Foreach',prev='Reset_duplicate_count',foreach="@outputs('Libraries_to_check')",actions=final_dupes,runtimeConfiguration={'concurrency':{'repetitions':1}})
    p['No_duplicate_before_rename']=guard("equals(variables('DuplicateCount'),0)", 'A duplicate appeared while processing; choose another number or name.', 'Check_libraries_final')
    p['Rename_message'] = setvar('FailureMessage','The rename or metadata update failed. Inspect the document and this flow run before retrying; partial changes may remain.', 'No_duplicate_before_rename')
    p['Rename_if_needed'] = condition("not(equals(body('Read_document')?['File']?['ServerRelativeUrl'],outputs('Destination_path')))",
        {'Rename_without_overwrite':http(file_uri+"/MoveToUsingPath(decodedurl='@{encodeUriComponent(replace(outputs('Destination_path'),'''',''''''))}',moveflags=0)",'POST',retry=False)},prev='Rename_message')
    p['Verify_rename'] = http(file_uri+'?$select=Name,ServerRelativeUrl',prev='Rename_if_needed')
    p['Require_expected_name'] = guard("equals(body('Verify_rename')?['ServerRelativeUrl'],outputs('Destination_path'))",'The saved filename/path did not match the requested name.', 'Verify_rename')
    p['Write_number_and_success'] = http(item_uri+'/ValidateUpdateListItem','POST',feedback('Completed',"@concat('Document number updated to ',variables('Number'),'.')","@variables('Number')"), 'Require_expected_name')
    p['Metadata_errors'] = action('Query',{'from':"@body('Write_number_and_success')?['value']",'where':"@equals(item()?['HasException'],true)"},'Write_number_and_success')
    p['Require_metadata_saved'] = guard("equals(length(body('Metadata_errors')),0)", 'SharePoint rejected one or more metadata values.', 'Metadata_errors')
    p['Verify_number'] = http(item_uri+'/FieldValuesAsText',prev='Require_metadata_saved')
    p['Require_number_matches'] = guard("and(equals(body('Verify_number')?[variables('Names')?['documentNumber']],variables('Number')),equals(body('Verify_number')?[variables('Names')?['status']],'Completed'))",'The document number/status could not be verified after saving.', 'Verify_number')
    a['Number_document'] = scope(p,'Configuration')
    # Feedback can fail too (e.g. permissions or continuing Office lock). The
    # flow retains a failed run and never reports that as a successful rename.
    catch = {
        'Only_write_owned_status': condition("variables('OwnsStatus')",
            {'Write_failure_feedback': http(item_uri+'/ValidateUpdateListItem','POST',feedback('Failed',"@substring(concat(variables('FailureMessage'),' Run: ',workflow()?['run']?['name']),0,min(255,length(concat(variables('FailureMessage'),' Run: ',workflow()?['run']?['name']))))"))}),
        'Fail_run': action('Terminate', {'runStatus':'Failed','runError':{'code':'SCGDocumentNumberingFailed','message':"@variables('FailureMessage')"}},'Only_write_owned_status')
    }
    catch['Fail_run']['runAfter']=after('Only_write_owned_status',['Succeeded','Failed','TimedOut','Skipped'])
    a['Report_failure'] = scope(catch)
    a['Report_failure']['runAfter']=after('Number_document',['Failed','TimedOut'])
    definition={'$schema':'https://schema.management.azure.com/providers/Microsoft.Logic/schemas/2016-06-01/workflowdefinition.json#',
        'contentVersion':VERSION,'parameters':params,'triggers':{'manual':trigger},'actions':a,'outputs':{}}
    return {'properties':{'connectionReferences':{'shared_sharepointonline':{'runtimeSource':'embedded',
                    'connection':{'connectionReferenceLogicalName':CONNECTION},'api':{'name':'shared_sharepointonline'}}},
            'definition':definition,'templateName':''},'schemaVersion':'1.0.0.0'}

def xmlfile(path, root):
    path.parent.mkdir(parents=True,exist_ok=True);ET.indent(root,space='  ')
    ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
def child(parent,name,text=None,**attrs):
    node=ET.SubElement(parent,name,attrs)
    if text is not None: node.text=str(text)
    return node

def build(output, bindings=None):
    source=output/'src';other=source/'Other';other.mkdir(parents=True,exist_ok=True)
    solution=ET.Element('ImportExportXml',{'version':'9.2.0.0','SolutionPackageVersion':'9.2','languagecode':'1033','generatedBy':'CrmLive'})
    manifest=child(solution,'SolutionManifest');child(manifest,'UniqueName','SCGDocumentNumbering')
    child(child(manifest,'LocalizedNames'),'LocalizedName',description='SCG Document Numbering',languagecode='1033')
    child(child(manifest,'Descriptions'),'Description',description='Project and corporate controlled-document numbering flows.',languagecode='1033')
    child(manifest,'Version',VERSION);child(manifest,'Managed','0')
    publisher=child(manifest,'Publisher');child(publisher,'UniqueName','SCGDocumentManagement')
    child(child(publisher,'LocalizedNames'),'LocalizedName',description='Security Consulting Group',languagecode='1033')
    child(publisher,'Descriptions');child(publisher,'CustomizationPrefix','scg');child(publisher,'CustomizationOptionValuePrefix','73190')
    child(publisher,'Addresses');roots=child(manifest,'RootComponents');child(manifest,'MissingDependencies')
    custom=ET.Element('ImportExportXml');child(custom,'Entities');child(custom,'Roles');child(custom,'Workflows')
    for tag in ['FieldSecurityProfiles','Templates','EntityMaps','EntityRelationships','OrganizationSettings','optionsets','CustomControls','EntityDataProviders']: child(custom,tag)
    refs=child(custom,'connectionreferences');ref=child(refs,'connectionreference',connectionreferencelogicalname=CONNECTION)
    child(ref,'connectionreferencedisplayname','SCG Document Numbering - SharePoint service account')
    child(ref,'connectorid','/providers/Microsoft.PowerApps/apis/shared_sharepointonline');child(ref,'iscustomizable','1');child(ref,'statecode','0');child(ref,'statuscode','1')
    child(child(custom,'Languages'),'Language','1033')
    # Shared environment values configure the two base flows. Library copies
    # embed their site/library/root values so they do not share bindings.
    env_defaults={'scg_SiteUrl':('SCG Site URL',''), 'scg_ProjectLibraryId':('SCG Project Library',''),
                  'scg_CorporateLibraryId':('SCG Corporate Library',''),
                  'scg_NumberingConfiguration':('SCG Numbering Configuration',json.dumps(CONFIG,separators=(',',':')))}
    for schema,(title,default) in env_defaults.items():
        env=ET.Element('environmentvariabledefinition',schemaname=schema)
        child(env,'defaultvalue',default);child(child(env,'displayname',default=title),'label',description=title,languagecode='1033')
        child(child(env,'description',default=title),'label',description=title,languagecode='1033')
        child(env,'introducedversion',VERSION);child(env,'iscustomizable','1');child(env,'isrequired','1');child(env,'secretstore','0');child(env,'type','100000000')
        xmlfile(source/'environmentvariabledefinitions'/schema/'environmentvariabledefinition.xml',env)
    flow_entries = [(family,None) for family in FLOW_IDS] if bindings is None else [(b['Family'],b) for b in bindings]
    flow_manifest=[]
    for family,binding in flow_entries:
        fid=FLOW_IDS[family] if binding is None else str(uuid.uuid5(NAMESPACE,f"{family}|{binding['SiteUrl'].lower()}|{binding['LibraryId'].lower()}"))
        title=f'SCG {family} Document Number Builder'
        if binding: title+=' - '+binding.get('LibraryTitle',binding['LibraryId'])
        filename=f'SCG{family}DocumentNumberBuilder-{fid.upper()}.json'
        document=flow(family,binding)
        if binding:
            # Remove environment variable metadata from library-specific values;
            # values are deliberately fixed to this library's configuration.
            parameter_names={key:'Configured_'+key.split('(')[1][:-1] for key in document['properties']['definition']['parameters'] if key.startswith('SCG ')}
            raw=json.dumps(document)
            for key,newkey in parameter_names.items():raw=raw.replace(key,newkey)
            document=json.loads(raw)
            for key in parameter_names.values():document['properties']['definition']['parameters'][key].pop('metadata',None)
        workflow=ET.Element('Workflow',WorkflowId='{'+fid+'}',Name=title)
        child(workflow,'JsonFileName','/Workflows/'+filename)
        for tag,value in {'Type':1,'Subprocess':0,'Category':5,'Mode':0,'Scope':4,'OnDemand':0,'TriggerOnCreate':0,'TriggerOnDelete':0,
            'AsyncAutodelete':0,'SyncWorkflowLogOnFailure':0,'StateCode':0,'StatusCode':1,'RunAs':1,'IsTransacted':1,
            'IntroducedVersion':VERSION,'IsCustomizable':1,'IsCustomProcessingStepAllowedForOtherPublishers':1,'PrimaryEntity':'none'}.items(): child(workflow,tag,value)
        child(child(workflow,'LocalizedNames'),'LocalizedName',languagecode='1033',description=title)
        xmlfile(source/'Workflows'/(filename+'.data.xml'),workflow)
        (source/'Workflows'/filename).write_text(json.dumps(document,indent=2),encoding='utf-8')
        child(roots,'RootComponent',type='29',id='{'+fid+'}',behavior='0')
        flow_manifest.append({'Family':family,'FlowId':fid,'DisplayName':title,**(binding or {})})
    xmlfile(other/'Solution.xml',solution);xmlfile(other/'Customizations.xml',custom)
    (output/'FlowManifest.json').write_text(json.dumps(flow_manifest,indent=2),encoding='utf-8')
    return source

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=ROOT/'Base')
    parser.add_argument('--bindings',type=Path);parser.add_argument('--pack',action='store_true');args=parser.parse_args()
    bindings=json.loads(args.bindings.read_text(encoding='utf-8-sig')) if args.bindings else None
    source=build(args.output,bindings)
    if args.pack:
        subprocess.run(['pac.cmd','solution','pack','--folder',str(source),'--zipfile',str(args.output/'SCGDocumentNumbering_1_0_0_0.zip'),'--packagetype','Unmanaged'],check=True)
    print(source)
