# SCG Document Numbering

Import **Base/SCGDocumentNumbering_1_0_0_0.zip** through Power Apps → Solutions → Import. This is an unmanaged Dataverse solution containing two cloud flows:

- SCG Project Document Number Builder
- SCG Corporate Document Number Builder

The flows import switched off. Bind the SharePoint connection reference to the connection owned by **SVC_SharePoint_DMSInternal_PowerAutomate**, configure the values below, then open, save and enable each flow. The connection needs permission to read all libraries in its duplicate scope, update metadata, check in and rename documents. The certificate in DeploymentSettings.json authenticates the supporting PowerShell scripts; cloud flows use their SharePoint connection reference.

## Configure the two flows

Supply these environment variable values during import (ImportSettings.json is an optional CLI settings template):

| Variable | Value |
|---|---|
| scg_SiteUrl | Full SharePoint site URL |
| scg_ProjectLibraryId | GUID of the project document library |
| scg_CorporateLibraryId | GUID of the corporate document library |
| scg_NumberingConfiguration | JSON configuration with both controlled parent content type IDs and the existing field GUIDs |

Copy the default JSON from Base/src/environmentvariabledefinitions/scg_NumberingConfiguration/environmentvariabledefinition.xml and fill in projectParentContentTypeId and corporateParentContentTypeId. The field GUIDs already match the XML supplied in this conversation. Parent names are **SCG Controlled Project Document** and **SCG Controlled Corporate Document**; their descendants qualify. The parent itself does not need to be applied to the library. Do not use the base flows with empty parent IDs.

Each selected-file flow binds to one library. These two base flows therefore serve one project library and one corporate library on the configured site. To cover every template library, generate library-specific copies using the CSV helper below. Copies have fixed site/library/parent parameters and share the service-account connection reference. The helper generates a single solution ZIP containing all eligible copies.

## Prepare all template libraries

Requires PowerShell 7.4+, PnP.PowerShell 3.1+, Python 3 and Microsoft Power Platform CLI (`pac`) on PATH. Use your **production** DeploymentSettings.json; no tenant credentials are included in this package. The scripts read BulkConfig.TenantId, ClientId, Thumbprint and TenantRootUrl and use the certificate already configured for deployment.

Edit TemplateSites.example.csv, then run:

```powershell
.\Prepare-LibrarySolution.ps1 -CsvPath .\TemplateSites.csv -ConfigPath 'C:\path\DeploymentSettings.json'
```

This reads sites and the publishing hub, discovers controlled content type descendants and produces LibraryBindings.json, FlowManifest.json and an import ZIP. It does not modify SharePoint or import a solution. Import the generated ZIP in place of the base ZIP when deploying all libraries. Review the discovered library list first. It does not create missing columns or synchronize content types: existing required fields must be present in each eligible library.

After import, give users run-only access and configure the SharePoint connector to use the supplied service-account connection. Record each actual cloud flow ID from its Details page URL. FlowManifest.json identifies the packaged workflow components; confirm actual flow IDs after import before using them in buttons.

## Install the row buttons

Fill in RowButtons.example.csv with one row per library, its actual imported flow IDs, and the corresponding controlled parent IDs. Leave the unused family's flow and parent blank. Preview first:

```powershell
.\Install-RowButtons.ps1 -CsvPath .\RowButtons.csv -ConfigPath 'C:\path\DeploymentSettings.json'
.\Install-RowButtons.ps1 -CsvPath .\RowButtons.csv -ConfigPath 'C:\path\DeploymentSettings.json' -Apply
```

The script backs up the existing trigger field schema and proposed formatter. Apply updates only the **Document Number Trigger** column formatter. It shows **Update SCG Document Number** for the appropriate content type descendants and disables it while **Document Number Builder Status** is In Progress. Include trigger and status columns in the **Document Number Updates** view. The previously supplied Set-DocumentNumberUpdatesView.ps1 builds that view; the revision title is **Document Revision** (DMSRevision).

SharePoint's Automate menu lists selected-file flows from the default Power Platform environment. Verify the executeFlow row button in your intended environment before rolling it out; importing in another environment does not guarantee SharePoint can launch it. The user must have run-only permission. Moving a flow into another solution in the same environment preserves its ID; copying/importing it into another environment requires checking the IDs and connection again.

## Numbering behavior

- Project example: SCG1234-SEC-DWG-0001-A_Security Pages Drawings list.docx.
- Corporate example: SCG-COR-QMS-POL-0005-A_Title.docx.
- Reads existing metadata, resolves immutable library field names by GUID, and checks field types. Taxonomy labels use the abbreviation before a spaced en dash, em dash or hyphen separator. Sequence must be four digits. Revision and sequence are supplied by the user; the flow does not allocate or increment them.
- Requires Project Number and Discipline for project numbering; Function and System for corporate numbering; Document Type, Sequence, Document Revision and Title for both. Project Number remains in the shared view as specified by the design, including corporate libraries; it is not a corporate filename segment.
- Checks proposed filenames across all folders in the selected library for project numbering, or all document libraries in the current SharePoint web for corporate numbering. Excludes the selected file itself and folders. Checks again immediately before rename. Rename never overwrites an existing destination.
- Preserves the original extension, rejects invalid filename characters and filenames over 255 characters, and checks the full decoded server-relative path against 400 characters.
- Attempts check-in preserving pending changes and waits for an Office lock to clear. It never discards a checkout or force-clears an active editing session. A checkout the service account cannot check in fails with feedback.
- Renames the file, writes Document Number, and verifies the filename, number and Completed status. Failures after acquiring In Progress status write Failed and a message with a run reference. Failures before field validation/status ownership are available in flow run history. Rename and metadata updates are separate operations; a later failure can leave partial changes. Inspect the file before retrying. Reset a stale In Progress status only after checking the original run.

Duplicate checks only were requested. No reservation list is created. Runs are serialized within each flow, but different flows/libraries can run simultaneously; corporate uniqueness across those runs is not guaranteed. Duplicate detection is based on the proposed **filename**, as specified in the design, rather than Document Number alone.

## Validation and acceptance

The ZIP is packed with Microsoft's Power Platform CLI. Offline tests check both design examples, invalid sequences/multiple taxonomy terms, action uniqueness/dependencies/references, path boundaries, duplicate scopes, repeated checks and no destructive checkout/overwrite. Supporting PowerShell scripts pass parser checks. No solution was imported into the SCG environment and no live SharePoint run was performed. Import acceptance, connection binding, launch permissions, SharePoint REST behavior and Office lock handling require verification in your tenant.

Before rollout, test one disposable document of each family: expected filename/number, rerun on itself, duplicate in another folder, corporate duplicate in another library, missing metadata, Document Revision, a locked document and an overlong path. Confirm failure feedback and original content preservation. Open both imported flows in the designer and save them before enabling.

Rebuild offline: `python build_solution.py --pack`. Run checks: `python test_solution.py`.
