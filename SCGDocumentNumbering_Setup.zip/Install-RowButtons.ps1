<#
.SYNOPSIS
Install numbering buttons after importing/enabling the flows.
.DESCRIPTION
CSV: SiteUrl,LibraryId,ProjectFlowId,CorporateFlowId,ProjectParentId,CorporateParentId.
Use actual cloud flow IDs from the imported flows' Details pages. Preview is default.
Uses production DeploymentSettings.json for certificate authentication.
#>
#requires -Version 7.4
[CmdletBinding(SupportsShouldProcess)]
param([Parameter(Mandatory)][string]$CsvPath,
    [string]$ConfigPath=(Join-Path $PSScriptRoot 'DeploymentSettings.json'),
    [switch]$Apply,
    [string]$OutputFolder=(Join-Path $PSScriptRoot ('ButtonBackup-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))))
$ErrorActionPreference='Stop'
Import-Module PnP.PowerShell -MinimumVersion 3.1.0
$config=(Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json -AsHashtable).BulkConfig
foreach($key in 'TenantId','ClientId','Thumbprint','TenantRootUrl'){if([string]::IsNullOrWhiteSpace($config[$key])){throw "Missing BulkConfig.$key"}}
$auth=@{Tenant=[Guid]$config.TenantId;ClientId=[Guid]$config.ClientId;Thumbprint=$config.Thumbprint;ReturnConnection=$true;ValidateConnection=$true;ErrorAction='Stop'}
$null=New-Item -Path $OutputFolder -ItemType Directory -Force
$rows=@(Import-Csv -LiteralPath $CsvPath)
if(-not $rows.Count){throw 'Button CSV is empty.'}
foreach($row in $rows) {
    $url=([string]$row.SiteUrl).Trim()
    if($url.StartsWith('/sites/') -or $url.StartsWith('/teams/')){$url=$config.TenantRootUrl.TrimEnd('/')+$url}
    if(([Uri]$url).Scheme -ne 'https' -or ([Uri]$url).Host -ine ([Uri]$config.TenantRootUrl).Host){throw "Unexpected site URL $url"}
    $listId=[Guid]$row.LibraryId
    $conn=Connect-PnPOnline -Url $url @auth
    $list=Get-PnPList -Identity $listId -Includes BaseTemplate -Connection $conn
    if($list.BaseTemplate -ne 101){throw 'Buttons require a document library.'}
    $fields=@(Get-PnPField -List $listId -Includes Id,InternalName,TypeAsString,SchemaXml -Connection $conn)
    $trigger=@($fields | Where-Object Id -EQ ([Guid]'522dd51b-0ecb-4937-afdb-820fee441d4a'))
    $status=@($fields | Where-Object Id -EQ ([Guid]'5720bd35-4483-430c-b50e-108df491792e'))
    if($trigger.Count -ne 1 -or $status.Count -ne 1 -or $trigger[0].TypeAsString -ne 'Text' -or $status[0].TypeAsString -ne 'Text'){throw 'Verified trigger/status Text columns are required.'}
    $buttons=@()
    foreach($family in 'Project','Corporate') {
        $flowId=[string]$row.($family+'FlowId');$parent=[string]$row.($family+'ParentId')
        if([string]::IsNullOrWhiteSpace($flowId)){continue}
        if($parent -notmatch '^0x0101[0-9a-f]+$'){throw "Supply the $family controlled parent ID."}
        $null=[Guid]$flowId
        $busy='[$'+$status[0].InternalName+"] == 'In Progress'"
        $buttons+=@{elmType='button';txtContent='Update SCG Document Number';customRowAction=@{action='executeFlow';actionParams=(@{id=$flowId;headerText="Update SCG $family Document Number";runFlowButtonText='Update document number'} | ConvertTo-Json -Compress)};
            attributes=@{disabled="=if($busy, 'true', '')";title="=if($busy, 'Document numbering is in progress', 'Update SCG Document Number')"};
            style=@{display=('=if(indexOf([$ContentTypeId], ''{0}'') == 0 && [$FSObjType] != ''1'', ''inline-block'', ''none'')' -f $parent);cursor="=if($busy, 'wait', 'pointer')";padding='5px 12px';'border-radius'='4px'}}
    }
    if(-not $buttons.Count){throw 'Supply at least one imported flow ID.'}
    $format=@{'$schema'='https://developer.microsoft.com/json-schemas/sp/v2/column-formatting.schema.json';elmType='div';children=$buttons} | ConvertTo-Json -Depth 15
    $backup=@{SiteUrl=$url;LibraryId=$listId;FieldId=$trigger[0].Id;SchemaXml=$trigger[0].SchemaXml;ProposedFormatter=$format}
    $backup | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $OutputFolder ($listId.ToString()+'.json'))
    if($Apply -and $PSCmdlet.ShouldProcess("$url / $($list.Title)",'Install document numbering row buttons')) {
        Set-PnPField -List $listId -Identity $trigger[0].Id -Values @{CustomFormatter=$format} -Connection $conn | Out-Null
        $saved=Get-PnPField -List $listId -Identity $trigger[0].Id -Includes CustomFormatter -Connection $conn
        if($saved.CustomFormatter -ne $format){throw "Could not verify the saved formatter for $url / $($list.Title)."}
        Write-Host "Installed and verified buttons for $url / $($list.Title)"
    } else {Write-Host "Preview saved for $url / $($list.Title)"}
}
