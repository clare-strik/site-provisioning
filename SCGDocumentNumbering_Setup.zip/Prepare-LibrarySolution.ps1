<#
.SYNOPSIS
Read CSV sites and produce a solution containing one numbering flow per eligible library.
.DESCRIPTION
SharePoint reads only. Requires production DeploymentSettings.json, PnP.PowerShell,
Python 3 and Power Platform CLI (pac). Does not import, enable flows or change SharePoint.
#>
#requires -Version 7.4
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$CsvPath,
    [string]$ConfigPath=(Join-Path $PSScriptRoot 'DeploymentSettings.json'),
    [string]$OutputFolder=(Join-Path $PSScriptRoot ('LibrarySolution-'+(Get-Date -Format 'yyyyMMdd-HHmmss')))
)
$ErrorActionPreference='Stop'
Import-Module PnP.PowerShell -MinimumVersion 3.1.0
$config=(Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json -AsHashtable).BulkConfig
foreach($key in 'TenantId','ClientId','Thumbprint','TenantRootUrl') {if([string]::IsNullOrWhiteSpace($config[$key])){throw "Missing BulkConfig.$key"}}
$auth=@{Tenant=[Guid]$config.TenantId;ClientId=[Guid]$config.ClientId;Thumbprint=$config.Thumbprint;ReturnConnection=$true;ValidateConnection=$true;ErrorAction='Stop'}
$sites=@(Import-Csv -LiteralPath $CsvPath)
if(-not $sites.Count -or 'SiteUrl' -notin $sites[0].PSObject.Properties.Name){throw 'CSV needs a SiteUrl column and at least one site.'}
$bindings=@();$hubTypes=$null
foreach($site in $sites) {
    $url=([string]$site.SiteUrl).Trim()
    if($url.StartsWith('/sites/') -or $url.StartsWith('/teams/')){$url=$config.TenantRootUrl.TrimEnd('/')+$url}
    $uri=[Uri]$url
    if($uri.Scheme -ne 'https' -or $uri.Host -ine ([Uri]$config.TenantRootUrl).Host -or $uri.Query -or $uri.Fragment -or $uri.UserInfo){throw "Unexpected site URL: $url"}
    $conn=Connect-PnPOnline -Url $url @auth
    if($null -eq $hubTypes){
        $hubUrl=Get-PnPContentTypePublishingHubUrl -Connection $conn
        $hubConn=Connect-PnPOnline -Url $hubUrl @auth
        $hubTypes=@(Get-PnPContentType -Connection $hubConn)
    }
    $parents=@{}
    foreach($family in 'Project','Corporate') {
        $types=@($hubTypes | Where-Object Name -EQ "SCG Controlled $family Document")
        if($types.Count -ne 1){throw "Expected one SCG Controlled $family Document parent in the hub."}
        $parents[$family]=[string]$types[0].Id.StringValue
    }
    foreach($list in @(Get-PnPList -Includes Id,Title,BaseTemplate,Hidden,IsCatalog,IsApplicationList -Connection $conn | Where-Object {$_.BaseTemplate -eq 101 -and -not $_.Hidden -and -not $_.IsCatalog -and -not $_.IsApplicationList})) {
        $cts=@(Get-PnPContentType -List $list -Connection $conn)
        foreach($family in 'Project','Corporate') {
            $parent=$parents[$family]
            if(@($cts | Where-Object {([string]$_.Id.StringValue).StartsWith($parent,[StringComparison]::OrdinalIgnoreCase)}).Count) {
                $bindings+=@{SiteUrl=$url.TrimEnd('/');LibraryId=([Guid]$list.Id).ToString();LibraryTitle=$list.Title;Family=$family;projectParentContentTypeId=$parents.Project;corporateParentContentTypeId=$parents.Corporate}
            }
        }
    }
}
$bindings=@($bindings | Sort-Object { $_.SiteUrl+'|'+$_.LibraryId+'|'+$_.Family } -Unique)
if(-not $bindings.Count){throw 'No eligible controlled document libraries found.'}
$null=New-Item -Path $OutputFolder -ItemType Directory -Force
$bindingPath=Join-Path $OutputFolder 'LibraryBindings.json'
ConvertTo-Json -InputObject $bindings -Depth 10 | Set-Content -LiteralPath $bindingPath -Encoding utf8
& python (Join-Path $PSScriptRoot 'build_solution.py') --bindings $bindingPath --output $OutputFolder --pack
if($LASTEXITCODE -ne 0){throw 'Solution generation/packing failed.'}
Write-Host "Import the generated ZIP, bind the SharePoint service-account connection, share run-only access and enable the flows. Review FlowManifest.json before installing buttons."
