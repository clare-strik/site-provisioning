"""Offline checks of the emitted flow expressions and solution structure."""
import json
import re
import unittest
import build_solution as builder


def evaluate(expression, outputs=None, variables=None):
    """Evaluate the WDL subset used by the numbering and metadata guards."""
    functions = {
        'outputs': lambda key: (outputs or {})[key],
        'variables': lambda key: (variables or {})[key],
        'concat': lambda *args: ''.join(str(a) for a in args),
        'replace': lambda value, old, new: value.replace(old, new),
        'trim': str.strip, 'split': str.split, 'first': lambda a: a[0],
        'last': lambda a: a[-1], 'length': len, 'empty': lambda a: not a,
        'not': lambda a: not a, 'and': lambda *a: all(a),
        'equals': lambda a, b: a == b, 'contains': lambda a, b: b in a,
        'lessOrEquals': lambda a, b: a <= b,
    }
    source = expression.removeprefix('@')
    pos = 0

    def parse():
        nonlocal pos
        if source[pos] == "'":
            pos += 1
            result = ''
            while pos < len(source):
                if source[pos] == "'":
                    pos += 1
                    if pos < len(source) and source[pos] == "'":
                        result += "'"; pos += 1
                    else:
                        return result
                else:
                    result += source[pos]; pos += 1
            raise ValueError('Unclosed string')
        token = re.match(r'[A-Za-z_]+|[0-9]+', source[pos:])[0]
        pos += len(token)
        if token.isdigit():
            return int(token)
        assert source[pos] == '('
        pos += 1
        args = []
        while source[pos] != ')':
            args.append(parse())
            if source[pos] == ',': pos += 1
        pos += 1
        return functions[token](*args)

    value = parse()
    assert pos == len(source)
    return value


def walk(actions):
    for name, action in actions.items():
        yield name, action
        yield from walk(action.get('actions', {}))
        yield from walk(action.get('else', {}).get('actions', {}))


class SolutionTests(unittest.TestCase):
    def test_dependencies_and_references(self):
        for family in builder.FLOW_IDS:
            definition = builder.flow(family)['properties']['definition']
            entries = list(walk(definition['actions']))
            names = [n for n, _ in entries]
            self.assertEqual(len(names), len(set(names)), 'Action names must be globally unique')
            def check_siblings(actions):
                for action in actions.values():
                    self.assertTrue(set(action['runAfter']) <= set(actions))
                    check_siblings(action.get('actions', {}))
                    check_siblings(action.get('else', {}).get('actions', {}))
            check_siblings(definition['actions'])
            serialized = json.dumps(definition)
            for name in re.findall(r"(?:outputs|body|items)\('([^']+)'\)", serialized):
                self.assertIn(name, names)
            for param in re.findall(r"parameters\('([^']+)'\)", serialized):
                self.assertIn(param, definition['parameters'])

    def test_design_examples_using_emitted_expressions(self):
        for family, expected in [('Project', 'SCG1234-SEC-DWG-0001-A'),
                                 ('Corporate', 'SCG-COR-QMS-POL-0005-A')]:
            actions = builder.flow(family)['properties']['definition']['actions']['Number_document']['actions']
            values = {'Value_projectNumber':'SCG1234', 'Value_discipline':'SEC – Security',
                      'Value_functionalScope':'COR - Corporate', 'Value_systemScope':'QMS — Quality',
                      'Value_documentType': 'DWG – Drawings' if family == 'Project' else 'POL – Policy',
                      'Value_sequence':'0001' if family == 'Project' else '0005', 'Value_revision':'A',
                      'Title':'Security Pages Drawings list'}
            for name, action in actions.items():
                if name.startswith('Abbreviation_'):
                    values[name] = evaluate(action['inputs'], values)
            self.assertTrue(evaluate(actions['Validate_required_values']['expression'], values))
            number = evaluate(actions['Build_number']['inputs']['value'], values)
            self.assertEqual(number, expected)
            values['Value_sequence'] = '12x4'
            self.assertFalse(evaluate(actions['Validate_required_values']['expression'], values))
            values['Value_sequence'] = '0001'
            values['Value_documentType'] = 'DWG;POL'
            self.assertFalse(evaluate(actions['Validate_required_values']['expression'], values))

    def test_path_limit_and_no_destructive_checkout(self):
        for family in builder.FLOW_IDS:
            flow = builder.flow(family)
            actions = flow['properties']['definition']['actions']['Number_document']['actions']
            for size, expected in [(399,True),(400,True),(401,False)]:
                self.assertEqual(evaluate(actions['Validate_path']['expression'], {'Destination_path':'x'*size}), expected)
            raw = json.dumps(flow).lower()
            self.assertNotIn('undocheckout', raw)
            self.assertNotIn('discardcheckout', raw)
            self.assertIn('moveflags=0', raw)
            self.assertIn('check_libraries_final', raw)
            self.assertNotIn('createlist', raw)
            self.assertEqual(flow['properties']['definition']['triggers']['manual']['runtimeConfiguration']['concurrency']['runs'], 1)

    def test_duplicate_scopes_and_source_exclusion(self):
        project = builder.flow('Project')['properties']['definition']['actions']['Number_document']['actions']
        corporate = builder.flow('Corporate')['properties']['definition']['actions']['Number_document']['actions']
        self.assertNotIn('Read_document_libraries', project)
        self.assertIn('Read_document_libraries', corporate)
        for actions in [project, corporate]:
            for passname in ['Check_libraries', 'Check_libraries_final']:
                raw = json.dumps(actions[passname])
                self.assertIn('RecursiveAll', raw)
                self.assertIn('FSObjType', raw)
                self.assertIn('ItemId', raw)
                self.assertIn('LibraryId', raw)
                self.assertIn('RowLimit>2', raw)


if __name__ == '__main__':
    unittest.main(verbosity=2)
